# Prism Medical Data Lab

Application Streamlit professionnelle pour l'analyse exploratoire, le nettoyage, le preprocessing, la visualisation et l'exportation de données médicales tabulaires.

## Vision du projet

Le projet est présenté comme une plateforme de travail de recherche pour étudiants, chercheurs et analystes en santé digitale. L'interface inclut un branding personnalisé, un logo, un dashboard moderne, des KPI cards, un workflow de recherche et des modules séparés pour garder le code propre.

## Fonctionnalités principales

- Branding complet avec logo SVG dans `assets/logo.svg` et mark dans `assets/brand_mark.svg`.
- Interface moderne Streamlit avec sidebar, hero section, cards, tabs et thème personnalisé.
- Importation CSV avec aperçu, dimensions, types, statistiques, mémoire et détection des doublons.
- Analyse exploratoire: statistiques, corrélations, heatmap, valeurs manquantes et doublons.
- Preprocessing: valeurs manquantes, doublons, outliers IQR, normalisation, standardisation, encodage, renommage, changement de types et sélection de colonnes.
- Visualisations interactives: histogrammes, boxplots, scatter plots, bar charts, pie charts, heatmap et séries temporelles.
- Exportation: dataset nettoyé en CSV/Excel, rapport d'analyse texte et graphique HTML.
- Historique des traitements pour documenter le workflow utilisateur.

## Installation

```bash
pip install -r requirements.txt
```

## Lancement

```bash
streamlit run app.py
```

L'application démarre avec `data/sample_medical_data.csv`. Vous pouvez importer un autre fichier CSV depuis la page `Importation des données`.

## Tests

```bash
pytest -q
```

## Architecture

```text
project/
├── app.py
├── .streamlit/config.toml
├── assets/
│   ├── logo.svg
│   └── brand_mark.svg
├── pages/
├── utils/
│   ├── data_loader.py
│   ├── preprocessing.py
│   ├── statistics.py
│   ├── visualization.py
│   ├── exporter.py
│   └── errors.py
├── data/
│   └── sample_medical_data.csv
├── exports/
├── tests/
├── requirements.txt
├── RUN_RECORD.md
└── COMPTE_RENDU.md
```