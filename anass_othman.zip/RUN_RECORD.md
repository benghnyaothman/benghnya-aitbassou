# Record de lancement et validation

## Commandes de préparation

```bash
pip install -r requirements.txt
```

## Commande de lancement de l'application

```bash
streamlit run app.py
```

Après lancement, ouvrir l'URL locale affichée par Streamlit, généralement `http://localhost:8501`.

## Scénario de démonstration

1. Ouvrir la page `Accueil` et présenter les KPI: lignes, colonnes, doublons et mémoire.
2. Aller à `Importation des données` et charger un fichier CSV médical.
3. Vérifier l'aperçu, les types, les colonnes numériques/catégorielles et les statistiques.
4. Aller à `Analyse exploratoire` pour afficher statistiques, corrélations, valeurs manquantes et doublons.
5. Aller à `Preprocessing` et appliquer nettoyage des valeurs manquantes, suppression des doublons, suppression des outliers, normalisation ou encodage.
6. Aller à `Visualisations` et générer des graphiques interactifs.
7. Aller à `Exportation` et télécharger CSV, Excel et rapport d'analyse.

## Validation effectuée

```bash
python -m compileall app.py utils tests
pytest -q
```

Résultat obtenu dans cet environnement:

```text
4 passed, 1 skipped
```

Le test Excel est ignoré localement car `openpyxl` n'est pas installé dans l'environnement courant. Il fonctionnera après installation des dépendances avec `pip install -r requirements.txt`.