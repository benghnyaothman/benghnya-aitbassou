from __future__ import annotations

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go


def histogram(df: pd.DataFrame, column: str, color: str | None = None):
    return px.histogram(df, x=column, color=color, marginal="box", title=f"Distribution de {column}")


def boxplot(df: pd.DataFrame, column: str, color: str | None = None):
    return px.box(df, y=column, color=color, title=f"Boxplot de {column}")


def scatter(df: pd.DataFrame, x: str, y: str, color: str | None = None):
    return px.scatter(df, x=x, y=y, color=color, title=f"Relation entre {x} et {y}")


def bar_chart(df: pd.DataFrame, column: str):
    counts = df[column].value_counts(dropna=False).reset_index()
    counts.columns = [column, "count"]
    return px.bar(counts, x=column, y="count", title=f"Répartition de {column}")


def pie_chart(df: pd.DataFrame, column: str):
    counts = df[column].value_counts(dropna=False).reset_index()
    counts.columns = [column, "count"]
    return px.pie(counts, names=column, values="count", title=f"Pie chart de {column}")


def heatmap(correlation: pd.DataFrame):
    return go.Figure(data=go.Heatmap(
        z=correlation.values,
        x=correlation.columns,
        y=correlation.index,
        colorscale="RdBu",
        zmid=0,
    )).update_layout(title="Matrice de corrélation")


def time_series(df: pd.DataFrame, date_column: str, value_column: str):
    data = df.copy()
    data[date_column] = pd.to_datetime(data[date_column], errors="coerce")
    data = data.dropna(subset=[date_column]).sort_values(date_column)
    return px.line(data, x=date_column, y=value_column, title=f"Évolution de {value_column}")