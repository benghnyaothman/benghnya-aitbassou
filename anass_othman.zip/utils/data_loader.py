from __future__ import annotations

from io import BytesIO, StringIO
from pathlib import Path

import pandas as pd

from .errors import DataValidationError


SUPPORTED_EXTENSIONS = {".csv"}


def load_csv(file) -> pd.DataFrame:
    """Load a CSV file from a path or Streamlit UploadedFile."""
    if isinstance(file, (str, Path)):
        path = Path(file)
        if path.suffix.lower() not in SUPPORTED_EXTENSIONS:
            raise DataValidationError("Seuls les fichiers CSV sont supportés.")
        return pd.read_csv(path)

    name = getattr(file, "name", "uploaded.csv")
    if Path(name).suffix.lower() != ".csv":
        raise DataValidationError("Seuls les fichiers CSV sont supportés.")

    content = file.getvalue()
    if isinstance(content, bytes):
        return pd.read_csv(BytesIO(content))
    return pd.read_csv(StringIO(content))


def dataset_overview(df: pd.DataFrame) -> dict:
    return {
        "rows": int(df.shape[0]),
        "columns": int(df.shape[1]),
        "duplicates": int(df.duplicated().sum()),
        "memory_mb": round(float(df.memory_usage(deep=True).sum() / 1024**2), 4),
        "numeric_columns": list(df.select_dtypes(include="number").columns),
        "categorical_columns": list(df.select_dtypes(exclude="number").columns),
    }