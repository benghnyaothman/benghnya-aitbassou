from __future__ import annotations

import pandas as pd


def descriptive_statistics(df: pd.DataFrame) -> pd.DataFrame:
    numeric = df.select_dtypes(include="number")
    if numeric.empty:
        return pd.DataFrame()
    stats = numeric.describe().T
    stats["median"] = numeric.median(numeric_only=True)
    stats["mode"] = numeric.mode().iloc[0]
    stats["variance"] = numeric.var(numeric_only=True)
    stats["missing"] = numeric.isna().sum()
    return stats.round(3)


def missing_values_table(df: pd.DataFrame) -> pd.DataFrame:
    missing = df.isna().sum()
    return pd.DataFrame({
        "missing_count": missing,
        "missing_percent": (missing / len(df) * 100).round(2) if len(df) else 0,
    }).sort_values("missing_count", ascending=False)


def correlation_matrix(df: pd.DataFrame) -> pd.DataFrame:
    numeric = df.select_dtypes(include="number")
    if numeric.shape[1] < 2:
        return pd.DataFrame()
    return numeric.corr().round(3)