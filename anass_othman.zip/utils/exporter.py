from __future__ import annotations

from io import BytesIO

import pandas as pd

from .statistics import descriptive_statistics, missing_values_table


def dataframe_to_csv_bytes(df: pd.DataFrame) -> bytes:
    return df.to_csv(index=False).encode("utf-8")


def dataframe_to_excel_bytes(df: pd.DataFrame) -> bytes:
    buffer = BytesIO()
    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="cleaned_data")
    return buffer.getvalue()


def analysis_report_text(df: pd.DataFrame, title: str = "Rapport d'analyse médicale") -> str:
    stats = descriptive_statistics(df)
    missing = missing_values_table(df)
    lines = [
        title,
        "=" * len(title),
        f"Nombre de lignes: {df.shape[0]}",
        f"Nombre de colonnes: {df.shape[1]}",
        f"Doublons: {df.duplicated().sum()}",
        "",
        "Valeurs manquantes:",
        missing.to_string(),
        "",
        "Statistiques descriptives:",
        stats.to_string() if not stats.empty else "Aucune colonne numérique.",
    ]
    return "\n".join(lines)