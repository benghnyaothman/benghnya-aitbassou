from __future__ import annotations

import numpy as np
import pandas as pd


def handle_missing_values(df: pd.DataFrame, strategy: str, custom_value: str | float | int | None = None) -> pd.DataFrame:
    result = df.copy()
    if strategy == "drop_rows":
        return result.dropna()
    if strategy == "drop_columns":
        return result.dropna(axis=1)
    if strategy in {"mean", "median"}:
        numeric_columns = result.select_dtypes(include="number").columns
        values = result[numeric_columns].mean() if strategy == "mean" else result[numeric_columns].median()
        result[numeric_columns] = result[numeric_columns].fillna(values)
        for column in result.select_dtypes(exclude="number").columns:
            mode = result[column].mode(dropna=True)
            if not mode.empty:
                result[column] = result[column].fillna(mode.iloc[0])
        return result
    if strategy == "mode":
        for column in result.columns:
            mode = result[column].mode(dropna=True)
            if not mode.empty:
                result[column] = result[column].fillna(mode.iloc[0])
        return result
    if strategy == "custom":
        return result.fillna(custom_value)
    return result


def remove_duplicates(df: pd.DataFrame) -> pd.DataFrame:
    return df.drop_duplicates().reset_index(drop=True)


def detect_outliers_iqr(df: pd.DataFrame, column: str) -> pd.Series:
    q1 = df[column].quantile(0.25)
    q3 = df[column].quantile(0.75)
    iqr = q3 - q1
    lower = q1 - 1.5 * iqr
    upper = q3 + 1.5 * iqr
    return (df[column] < lower) | (df[column] > upper)


def remove_outliers_iqr(df: pd.DataFrame, columns: list[str]) -> pd.DataFrame:
    result = df.copy()
    for column in columns:
        if column in result.select_dtypes(include="number").columns:
            result = result.loc[~detect_outliers_iqr(result, column)]
    return result.reset_index(drop=True)


def normalize_columns(df: pd.DataFrame, columns: list[str]) -> pd.DataFrame:
    result = df.copy()
    for column in columns:
        min_value = result[column].min()
        max_value = result[column].max()
        if max_value != min_value:
            result[column] = (result[column] - min_value) / (max_value - min_value)
    return result


def standardize_columns(df: pd.DataFrame, columns: list[str]) -> pd.DataFrame:
    result = df.copy()
    for column in columns:
        std = result[column].std()
        if std and not np.isnan(std):
            result[column] = (result[column] - result[column].mean()) / std
    return result


def encode_categorical(df: pd.DataFrame, columns: list[str]) -> pd.DataFrame:
    return pd.get_dummies(df, columns=columns, drop_first=False)


def change_column_types(df: pd.DataFrame, conversions: dict[str, str]) -> pd.DataFrame:
    result = df.copy()
    for column, dtype in conversions.items():
        if dtype == "datetime":
            result[column] = pd.to_datetime(result[column], errors="coerce")
        else:
            result[column] = result[column].astype(dtype)
    return result