class DataValidationError(ValueError):
    """Raised when uploaded data cannot be processed safely."""


def require_columns(df, columns):
    missing = [column for column in columns if column not in df.columns]
    if missing:
        raise DataValidationError(f"Colonnes manquantes: {', '.join(missing)}")