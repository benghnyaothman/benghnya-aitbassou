from __future__ import annotations

import base64
from pathlib import Path

import pandas as pd
import streamlit as st

from utils.data_loader import dataset_overview, load_csv
from utils.errors import DataValidationError
from utils.exporter import analysis_report_text, dataframe_to_csv_bytes, dataframe_to_excel_bytes
from utils.preprocessing import (
    change_column_types,
    encode_categorical,
    handle_missing_values,
    normalize_columns,
    remove_duplicates,
    remove_outliers_iqr,
    standardize_columns,
)
from utils.statistics import correlation_matrix, descriptive_statistics, missing_values_table
from utils.visualization import bar_chart, boxplot, heatmap, histogram, pie_chart, scatter, time_series

APP_NAME = "Prism Medical Data Lab"
APP_SUBTITLE = "Research-grade platform for medical data exploration and preprocessing"
LOGO_PATH = Path("assets/logo.svg")
MARK_PATH = Path("assets/brand_mark.svg")
SAMPLE_DATA_PATH = Path("data/sample_medical_data.csv")

st.set_page_config(page_title=APP_NAME, page_icon="🧬", layout="wide")


def svg_data_uri(path: Path) -> str:
    if not path.exists():
        return ""
    encoded = base64.b64encode(path.read_bytes()).decode("utf-8")
    return f"data:image/svg+xml;base64,{encoded}"


def inject_css() -> None:
    st.markdown(
        """
        <style>
        :root {
            --primary: #0f766e;
            --primary-dark: #115e59;
            --accent: #2563eb;
            --cyan: #22d3ee;
            --ink: #0f172a;
            --muted: #64748b;
            --surface: #ffffff;
            --soft: #f1f5f9;
            --border: #e2e8f0;
        }
        .main .block-container {
            padding-top: 1.1rem;
            padding-bottom: 3rem;
            max-width: 1280px;
        }
        [data-testid="stSidebar"] {
            background: linear-gradient(180deg, #0f172a 0%, #115e59 54%, #0f766e 100%);
        }
        [data-testid="stSidebar"] * { color: #f8fafc !important; }
        [data-testid="stSidebar"] .stRadio label,
        [data-testid="stSidebar"] .stToggle label { font-weight: 700; }
        .hero {
            padding: 2rem;
            border-radius: 28px;
            color: white;
            background: radial-gradient(circle at 10% 20%, rgba(34,211,238,.35), transparent 24%),
                        linear-gradient(135deg, #0f172a 0%, #0f766e 48%, #2563eb 100%);
            box-shadow: 0 24px 70px rgba(15, 23, 42, .18);
            margin-bottom: 1.4rem;
        }
        .hero h1 { font-size: 3rem; line-height: 1.05; margin: .25rem 0 .6rem; color: white; }
        .hero p { color: #dffafe; font-size: 1.08rem; max-width: 850px; }
        .hero-badge {
            display: inline-flex; gap: .55rem; align-items: center;
            background: rgba(255,255,255,.14); border: 1px solid rgba(255,255,255,.25);
            border-radius: 999px; padding: .42rem .78rem; font-weight: 800; color: white;
        }
        .section-card {
            background: var(--surface); border: 1px solid var(--border); border-radius: 22px;
            padding: 1.2rem 1.25rem; box-shadow: 0 12px 35px rgba(15,23,42,.06);
            margin-bottom: 1rem;
        }
        .feature-card {
            background: linear-gradient(180deg, #ffffff, #f8fafc); border: 1px solid var(--border);
            border-radius: 20px; padding: 1.15rem; height: 100%; box-shadow: 0 10px 28px rgba(15,23,42,.055);
        }
        .feature-card h3 { margin: .2rem 0 .4rem; color: var(--ink); font-size: 1.05rem; }
        .feature-card p { color: var(--muted); margin: 0; font-size: .93rem; }
        .metric-card {
            border-radius: 22px; padding: 1.1rem 1.15rem; color: white;
            background: linear-gradient(135deg, #0f766e, #2563eb);
            box-shadow: 0 15px 35px rgba(37,99,235,.17);
        }
        .metric-card .label { opacity: .88; font-size: .85rem; font-weight: 800; text-transform: uppercase; letter-spacing: .06em; }
        .metric-card .value { font-size: 2rem; font-weight: 900; margin-top: .25rem; }
        .metric-card .hint { opacity: .82; font-size: .82rem; margin-top: .15rem; }
        .workflow-step {
            display: flex; gap: .8rem; align-items: flex-start; padding: .8rem .9rem;
            border-left: 4px solid var(--primary); background: #f8fafc; border-radius: 14px; margin-bottom: .65rem;
        }
        .step-number {
            min-width: 2rem; height: 2rem; border-radius: 50%; display: grid; place-items: center;
            background: var(--primary); color: white; font-weight: 900;
        }
        .page-title { color: var(--ink); font-size: 2.1rem; margin-bottom: .25rem; }
        .page-subtitle { color: var(--muted); margin-bottom: 1.2rem; }
        .stTabs [data-baseweb="tab-list"] { gap: .5rem; }
        .stTabs [data-baseweb="tab"] {
            border-radius: 999px; padding: .6rem 1rem; background: #f1f5f9; font-weight: 800;
        }
        div[data-testid="stMetric"] {
            background: white; border: 1px solid var(--border); padding: 1rem; border-radius: 18px;
            box-shadow: 0 10px 28px rgba(15,23,42,.05);
        }
        .small-muted { color: #64748b; font-size: .9rem; }
        </style>
        """,
        unsafe_allow_html=True,
    )


def init_state() -> None:
    if "df" not in st.session_state:
        st.session_state.df = pd.read_csv(SAMPLE_DATA_PATH)
    if "original_df" not in st.session_state:
        st.session_state.original_df = st.session_state.df.copy()
    if "history" not in st.session_state:
        st.session_state.history = ["Chargement du dataset médical d'exemple"]


def set_data(df: pd.DataFrame, action: str) -> None:
    st.session_state.df = df
    st.session_state.history.append(action)


def page_header(title: str, subtitle: str, icon: str) -> None:
    st.markdown(f"<h1 class='page-title'>{icon} {title}</h1><p class='page-subtitle'>{subtitle}</p>", unsafe_allow_html=True)


def metric_cards(df: pd.DataFrame) -> None:
    overview = dataset_overview(df)
    missing_cells = int(df.isna().sum().sum())
    numeric_count = len(overview["numeric_columns"])
    values = [
        ("Patients / lignes", overview["rows"], "Observations disponibles"),
        ("Variables", overview["columns"], f"{numeric_count} numériques"),
        ("Doublons", overview["duplicates"], "Qualité des données"),
        ("Valeurs manquantes", missing_cells, f"Mémoire: {overview['memory_mb']} MB"),
    ]
    cols = st.columns(4)
    for col, (label, value, hint) in zip(cols, values):
        col.markdown(
            f"""
            <div class="metric-card">
              <div class="label">{label}</div>
              <div class="value">{value}</div>
              <div class="hint">{hint}</div>
            </div>
            """,
            unsafe_allow_html=True,
        )


def sidebar() -> str:
    with st.sidebar:
        if MARK_PATH.exists():
            st.image(str(MARK_PATH), width=78)
        st.markdown("### Prism Medical Lab")
        st.caption("Research data cleaning, EDA & reporting")
        st.divider()
        page = st.radio(
            "Navigation",
            [
                "Accueil",
                "Importation des données",
                "Analyse exploratoire",
                "Preprocessing",
                "Visualisations",
                "Exportation",
                "À propos",
            ],
            label_visibility="collapsed",
        )
        st.divider()
        st.toggle("Mode sombre", value=False, help="Le thème Streamlit peut être changé depuis les paramètres de l'application.")
        st.caption("Version recherche • Python + Streamlit")
        return page


def render_home(df: pd.DataFrame) -> None:
    logo_uri = svg_data_uri(LOGO_PATH)
    logo_html = f"<img src='{logo_uri}' style='width: min(520px, 100%); margin-bottom: 1rem;' />" if logo_uri else ""
    st.markdown(
        f"""
        <div class="hero">
          {logo_html}
          <div class="hero-badge">🧬 Projet de recherche • Données médicales</div>
          <h1>{APP_NAME}</h1>
          <p>{APP_SUBTITLE}. Une plateforme professionnelle pour préparer des datasets médicaux avant analyse scientifique, reporting ou machine learning.</p>
        </div>
        """,
        unsafe_allow_html=True,
    )
    metric_cards(df)
    st.write("")

    features = st.columns(4)
    feature_content = [
        ("📥 Import contrôlé", "Chargement CSV, détection automatique des types, doublons et mémoire."),
        ("🔎 Analyse EDA", "Statistiques, corrélations, valeurs manquantes et distributions."),
        ("🧹 Preprocessing", "Nettoyage, outliers, normalisation, standardisation et encodage."),
        ("📤 Export recherche", "CSV, Excel, rapport analytique et graphiques réutilisables."),
    ]
    for col, (title, body) in zip(features, feature_content):
        col.markdown(f"<div class='feature-card'><h3>{title}</h3><p>{body}</p></div>", unsafe_allow_html=True)

    st.markdown("### Dashboard analytique rapide")
    numeric = df.select_dtypes(include="number").columns.tolist()
    categorical = df.select_dtypes(exclude="number").columns.tolist()
    left, right = st.columns([1.05, 1])
    with left:
        st.markdown("<div class='section-card'>", unsafe_allow_html=True)
        st.markdown("#### Aperçu du dataset")
        st.dataframe(df.head(20), use_container_width=True, hide_index=True)
        st.markdown("</div>", unsafe_allow_html=True)
    with right:
        st.markdown("<div class='section-card'>", unsafe_allow_html=True)
        st.markdown("#### Visualisation automatique")
        if numeric:
            st.plotly_chart(histogram(df, numeric[0], categorical[0] if categorical else None), use_container_width=True)
        elif categorical:
            st.plotly_chart(bar_chart(df, categorical[0]), use_container_width=True)
        st.markdown("</div>", unsafe_allow_html=True)

    st.markdown("### Workflow de recherche")
    steps = [
        ("Importer", "Charger un fichier CSV médical et vérifier la structure."),
        ("Explorer", "Comprendre les distributions, corrélations et valeurs manquantes."),
        ("Nettoyer", "Appliquer les traitements nécessaires pour obtenir un dataset fiable."),
        ("Visualiser", "Créer des graphiques interactifs pour interpréter les résultats."),
        ("Exporter", "Télécharger les données nettoyées et le rapport d'analyse."),
    ]
    for index, (title, body) in enumerate(steps, start=1):
        st.markdown(
            f"<div class='workflow-step'><div class='step-number'>{index}</div><div><b>{title}</b><br><span class='small-muted'>{body}</span></div></div>",
            unsafe_allow_html=True,
        )


def render_import(df: pd.DataFrame) -> None:
    page_header("Importation des données", "Chargez un fichier CSV médical et inspectez immédiatement sa structure.", "📥")
    uploaded = st.file_uploader("Importer un fichier CSV", type=["csv"], help="Format accepté: CSV uniquement.")
    if uploaded:
        try:
            loaded_df = load_csv(uploaded)
            st.session_state.original_df = loaded_df.copy()
            set_data(loaded_df, f"Importation du fichier {uploaded.name}")
            st.success("Fichier chargé avec succès.")
            df = loaded_df
        except DataValidationError as error:
            st.error(str(error))
    metric_cards(df)
    tab_preview, tab_types, tab_quality = st.tabs(["Aperçu", "Types & colonnes", "Qualité"])
    with tab_preview:
        st.dataframe(df.head(80), use_container_width=True, hide_index=True)
        st.dataframe(df.describe(include="all").T, use_container_width=True)
    with tab_types:
        col1, col2 = st.columns(2)
        overview = dataset_overview(df)
        col1.markdown("#### Colonnes numériques")
        col1.write(overview["numeric_columns"] or "Aucune")
        col2.markdown("#### Colonnes catégorielles")
        col2.write(overview["categorical_columns"] or "Aucune")
        st.dataframe(df.dtypes.astype(str).rename("type"), use_container_width=True)
    with tab_quality:
        st.json(dataset_overview(df))
        st.dataframe(missing_values_table(df), use_container_width=True)


def render_eda(df: pd.DataFrame) -> None:
    page_header("Analyse exploratoire", "Analyse statistique, corrélations, valeurs manquantes et doublons.", "🔎")
    metric_cards(df)
    tab_stats, tab_corr, tab_missing, tab_duplicates = st.tabs(["Statistiques", "Corrélations", "Valeurs manquantes", "Doublons"])
    with tab_stats:
        st.dataframe(descriptive_statistics(df), use_container_width=True)
    with tab_corr:
        corr = correlation_matrix(df)
        if corr.empty:
            st.info("Il faut au moins deux colonnes numériques.")
        else:
            st.plotly_chart(heatmap(corr), use_container_width=True)
            st.dataframe(corr, use_container_width=True)
    with tab_missing:
        missing = missing_values_table(df)
        st.dataframe(missing, use_container_width=True)
        st.bar_chart(missing["missing_count"])
    with tab_duplicates:
        duplicated = df[df.duplicated(keep=False)]
        st.metric("Nombre de doublons", int(df.duplicated().sum()))
        st.dataframe(duplicated, use_container_width=True, hide_index=True)


def render_preprocessing(df: pd.DataFrame) -> None:
    page_header("Preprocessing", "Nettoyez, transformez et documentez les traitements appliqués au dataset.", "🧹")
    before, after, history = st.columns(3)
    before.metric("Lignes initiales", st.session_state.original_df.shape[0])
    after.metric("Lignes actuelles", df.shape[0])
    history.metric("Étapes appliquées", len(st.session_state.history))

    tab_missing, tab_cleaning, tab_transform, tab_columns, tab_history = st.tabs([
        "Valeurs manquantes", "Doublons & outliers", "Transformations", "Colonnes", "Historique"
    ])

    with tab_missing:
        st.dataframe(missing_values_table(df), use_container_width=True)
        strategy_label = st.selectbox("Stratégie", ["Aucune", "Supprimer lignes", "Supprimer colonnes", "Moyenne", "Médiane", "Mode", "Valeur personnalisée"])
        strategy_map = {"Supprimer lignes": "drop_rows", "Supprimer colonnes": "drop_columns", "Moyenne": "mean", "Médiane": "median", "Mode": "mode", "Valeur personnalisée": "custom"}
        custom_value = st.text_input("Valeur personnalisée", value="0")
        if st.button("Appliquer le traitement", type="primary") and strategy_label != "Aucune":
            set_data(handle_missing_values(df, strategy_map[strategy_label], custom_value), f"Valeurs manquantes: {strategy_label}")
            st.success("Traitement appliqué.")
            st.rerun()

    with tab_cleaning:
        col1, col2 = st.columns(2)
        with col1:
            st.markdown("#### Doublons")
            st.metric("Lignes dupliquées", int(df.duplicated().sum()))
            if st.button("Supprimer les doublons", type="primary"):
                set_data(remove_duplicates(df), "Suppression des doublons")
                st.success("Doublons supprimés.")
                st.rerun()
        with col2:
            st.markdown("#### Outliers IQR")
            numeric = df.select_dtypes(include="number").columns.tolist()
            outlier_cols = st.multiselect("Colonnes numériques", numeric)
            if st.button("Supprimer les outliers") and outlier_cols:
                set_data(remove_outliers_iqr(df, outlier_cols), f"Suppression outliers: {', '.join(outlier_cols)}")
                st.success("Outliers supprimés.")
                st.rerun()

    with tab_transform:
        numeric = df.select_dtypes(include="number").columns.tolist()
        categorical = df.select_dtypes(exclude="number").columns.tolist()
        transform_cols = st.multiselect("Colonnes numériques à transformer", numeric, key="transform_cols")
        col_a, col_b = st.columns(2)
        if col_a.button("Normaliser Min-Max") and transform_cols:
            set_data(normalize_columns(df, transform_cols), "Normalisation Min-Max")
            st.rerun()
        if col_b.button("Standardiser Z-score") and transform_cols:
            set_data(standardize_columns(df, transform_cols), "Standardisation Z-score")
            st.rerun()
        cat_cols = st.multiselect("Colonnes catégorielles à encoder", categorical)
        if st.button("Encoder les variables catégorielles") and cat_cols:
            set_data(encode_categorical(df, cat_cols), "Encodage catégoriel")
            st.rerun()

    with tab_columns:
        selected_cols = st.multiselect("Variables utiles", df.columns.tolist(), default=df.columns.tolist())
        if st.button("Garder seulement ces colonnes"):
            set_data(df[selected_cols].copy(), "Sélection de colonnes")
            st.rerun()
        col1, col2 = st.columns(2)
        rename_column = col1.selectbox("Renommer colonne", df.columns.tolist())
        new_name = col2.text_input("Nouveau nom")
        if st.button("Renommer") and new_name:
            set_data(df.rename(columns={rename_column: new_name}), f"Renommage {rename_column} -> {new_name}")
            st.rerun()
        type_column = st.selectbox("Changer type", df.columns.tolist(), key="type_column")
        dtype = st.selectbox("Nouveau type", ["str", "float", "int", "datetime"])
        if st.button("Changer le type"):
            try:
                set_data(change_column_types(df, {type_column: dtype}), f"Type {type_column}: {dtype}")
                st.success("Type modifié.")
                st.rerun()
            except Exception as error:
                st.error(f"Conversion impossible: {error}")
        st.dataframe(df, use_container_width=True, hide_index=True)

    with tab_history:
        for index, action in enumerate(st.session_state.history, start=1):
            st.markdown(f"<div class='workflow-step'><div class='step-number'>{index}</div><div>{action}</div></div>", unsafe_allow_html=True)


def render_visualisations(df: pd.DataFrame) -> None:
    page_header("Visualisations", "Créez des graphiques interactifs pour l'analyse scientifique et le reporting.", "📊")
    numeric = df.select_dtypes(include="number").columns.tolist()
    categorical = df.select_dtypes(exclude="number").columns.tolist()
    chart_type = st.selectbox("Type de graphique", ["Histogramme", "Boxplot", "Scatter", "Bar chart", "Pie chart", "Heatmap", "Série temporelle"])
    fig = None
    if chart_type in {"Histogramme", "Boxplot"} and numeric:
        y = st.selectbox("Colonne numérique", numeric)
        color = st.selectbox("Couleur / groupe", [None] + categorical)
        fig = histogram(df, y, color) if chart_type == "Histogramme" else boxplot(df, y, color)
    elif chart_type == "Scatter" and len(numeric) >= 2:
        x = st.selectbox("Axe X", numeric)
        y = st.selectbox("Axe Y", numeric, index=1)
        color = st.selectbox("Couleur / groupe", [None] + categorical)
        fig = scatter(df, x, y, color)
    elif chart_type in {"Bar chart", "Pie chart"} and categorical:
        column = st.selectbox("Colonne catégorielle", categorical)
        fig = bar_chart(df, column) if chart_type == "Bar chart" else pie_chart(df, column)
    elif chart_type == "Heatmap":
        corr = correlation_matrix(df)
        fig = None if corr.empty else heatmap(corr)
    elif chart_type == "Série temporelle" and numeric:
        date_col = st.selectbox("Colonne date", df.columns.tolist())
        value_col = st.selectbox("Valeur", numeric)
        fig = time_series(df, date_col, value_col)

    if fig is None:
        st.info("Choisissez des colonnes compatibles avec ce graphique.")
    else:
        st.plotly_chart(fig, use_container_width=True)
        st.download_button("Télécharger le graphique HTML", fig.to_html().encode("utf-8"), "graphique_recherche.html", "text/html")


def render_export(df: pd.DataFrame) -> None:
    page_header("Exportation", "Téléchargez les données nettoyées, graphiques et rapports d'analyse.", "📤")
    report = analysis_report_text(df)
    col1, col2, col3 = st.columns(3)
    col1.download_button("⬇️ CSV nettoyé", dataframe_to_csv_bytes(df), "dataset_nettoye.csv", "text/csv", use_container_width=True)
    try:
        excel_bytes = dataframe_to_excel_bytes(df)
        col2.download_button("⬇️ Excel nettoyé", excel_bytes, "dataset_nettoye.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", use_container_width=True)
    except ModuleNotFoundError:
        col2.warning("Installez openpyxl pour activer l'export Excel.")
    col3.download_button("⬇️ Rapport TXT", report.encode("utf-8"), "rapport_analyse.txt", "text/plain", use_container_width=True)
    st.text_area("Aperçu du rapport", report, height=360)


def render_about() -> None:
    page_header("À propos", "Présentation académique et scientifique du projet.", "ℹ️")
    st.markdown(
        """
        <div class="section-card">
        <h3>Prism Medical Data Lab</h3>
        <p>Application développée pour le projet <b>Sciences de Données Médicales par Python</b>. Elle aide les chercheurs et étudiants à préparer des datasets médicaux avant analyse statistique, reporting ou modélisation.</p>
        </div>
        """,
        unsafe_allow_html=True,
    )
    col1, col2 = st.columns(2)
    with col1:
        st.markdown("#### Technologies")
        st.write(["Python", "Streamlit", "Pandas", "NumPy", "Plotly", "Matplotlib", "OpenPyXL", "Pytest"])
    with col2:
        st.markdown("#### Livrables")
        st.write(["Application web", "Rapport détaillé", "Tests unitaires", "Record de démonstration", "Code source structuré"])


def main() -> None:
    inject_css()
    init_state()
    page = sidebar()
    current_df = st.session_state.df

    if page == "Accueil":
        render_home(current_df)
    elif page == "Importation des données":
        render_import(current_df)
    elif page == "Analyse exploratoire":
        render_eda(current_df)
    elif page == "Preprocessing":
        render_preprocessing(current_df)
    elif page == "Visualisations":
        render_visualisations(current_df)
    elif page == "Exportation":
        render_export(current_df)
    elif page == "À propos":
        render_about()


if __name__ == "__main__":
    main()