# Rapport du projet: Prism Medical Data Lab

## Page de garde

- **Filière:** 2ème année Licence Informatique Décisionnelle en Santé Digitale
- **Module:** Sciences de Données Médicales par Python
- **Titre du projet:** Développement d'une application web interactive pour l'analyse et le preprocessing des données médicales
- **Nom de l'application:** Prism Medical Data Lab
- **Technologies principales:** Python, Streamlit, Pandas, NumPy, Plotly, Matplotlib, OpenPyXL

## 1. Introduction

Les établissements de santé produisent de grandes quantités de données: dossiers patients, résultats biologiques, données de suivi clinique, indicateurs hospitaliers ou informations de santé publique. Avant de pouvoir exploiter ces données dans un contexte décisionnel ou analytique, il est nécessaire de les explorer, les nettoyer, les transformer et les visualiser.

Ce projet propose une application web interactive appelée **Prism Medical Data Lab**. Elle permet à un utilisateur non spécialiste en programmation d'importer un fichier CSV médical, de comprendre rapidement sa structure, d'identifier les problèmes de qualité des données, d'appliquer plusieurs techniques de preprocessing, puis d'exporter les résultats sous différents formats.

## 2. Problématique

Les datasets médicaux contiennent souvent des valeurs manquantes, des doublons, des colonnes mal typées, des variables catégorielles, des valeurs aberrantes et des distributions difficiles à interpréter. Ces problèmes peuvent fausser les analyses statistiques et réduire la qualité des décisions.

La problématique traitée est donc la suivante:

> Comment développer une application simple, interactive et complète permettant d'analyser, nettoyer, prétraiter, visualiser et exporter des données médicales tabulaires avec Python?

## 3. Objectifs du projet

L'objectif général est de créer une plateforme interactive dédiée aux sciences de données médicales. Les objectifs spécifiques sont:

- permettre l'importation de fichiers CSV;
- afficher un aperçu complet du dataset;
- détecter les colonnes numériques et catégorielles;
- calculer les statistiques descriptives;
- analyser les corrélations entre variables numériques;
- détecter les valeurs manquantes et les doublons;
- appliquer des techniques de nettoyage et de preprocessing;
- générer des visualisations interactives;
- exporter les données nettoyées et les rapports d'analyse;
- proposer une interface claire, moderne et organisée.

## 4. Technologies utilisées

### 4.1 Python

Python est utilisé comme langage principal du projet. Il permet de développer rapidement des applications de data science grâce à son écosystème riche.

### 4.2 Streamlit

Streamlit permet de créer une interface web interactive sans développer manuellement une application frontend complexe. Il est utilisé pour la sidebar, les pages, les boutons, les tableaux, les graphiques et les téléchargements.

### 4.3 Pandas et NumPy

Pandas est utilisé pour la lecture des fichiers CSV, la manipulation des DataFrames, les statistiques, le traitement des valeurs manquantes et l'exportation. NumPy est utilisé pour certaines opérations numériques, notamment dans la standardisation.

### 4.4 Plotly et Matplotlib

Plotly sert à générer des graphiques interactifs comme les histogrammes, boxplots, scatter plots, pie charts et heatmaps. Matplotlib est prévu comme bibliothèque de visualisation complémentaire.

### 4.5 OpenPyXL

OpenPyXL est utilisé par Pandas pour exporter les datasets nettoyés au format Excel.

### 4.6 Pytest

Pytest est utilisé pour tester automatiquement les modules principaux de l'application.

## 5. Architecture du projet

Le projet est organisé de manière modulaire afin de faciliter la maintenance et l'évolution de l'application.

```text
project/
├── app.py
├── pages/
├── utils/
│   ├── data_loader.py
│   ├── preprocessing.py
│   ├── statistics.py
│   ├── visualization.py
│   ├── exporter.py
│   └── errors.py
├── data/
│   └── sample_medical_data.csv
├── exports/
├── assets/
├── tests/
│   ├── conftest.py
│   └── test_processing.py
├── requirements.txt
├── README.md
├── RUN_RECORD.md
└── COMPTE_RENDU.md
```

### 5.1 Rôle des fichiers principaux

- `app.py`: contient l'interface principale Streamlit et la navigation entre les pages.
- `utils/data_loader.py`: gère le chargement des fichiers CSV et la génération du résumé global du dataset.
- `utils/statistics.py`: calcule les statistiques descriptives, les corrélations et le tableau des valeurs manquantes.
- `utils/preprocessing.py`: regroupe les fonctions de nettoyage et transformation des données.
- `utils/visualization.py`: contient les fonctions de création des graphiques interactifs.
- `utils/exporter.py`: prépare les fichiers à télécharger: CSV, Excel et rapport texte.
- `utils/errors.py`: contient la classe d'erreur personnalisée pour la validation des données.
- `tests/test_processing.py`: teste les fonctions principales du projet.

## 6. Description détaillée de l'application

### 6.1 Page Accueil

La page d'accueil présente l'application et affiche des indicateurs clés sous forme de KPI cards:

- nombre de lignes;
- nombre de colonnes;
- nombre de doublons;
- mémoire utilisée par le dataset.

Elle affiche aussi un aperçu du dataset et un premier graphique pour donner une vision rapide des données chargées.

### 6.2 Page Importation des données

Cette page permet d'importer un fichier CSV. Après importation, l'application affiche:

- les premières lignes du dataset;
- les dimensions du tableau;
- les types des colonnes;
- les colonnes numériques;
- les colonnes catégorielles;
- le nombre de doublons;
- la mémoire utilisée.

Un dataset médical d'exemple est chargé automatiquement au démarrage afin de permettre de tester l'application sans importer de fichier externe.

### 6.3 Page Analyse exploratoire

Cette partie permet de comprendre la structure et le contenu des données. Elle contient quatre onglets principaux.

#### Statistiques descriptives

L'application calcule pour les variables numériques:

- moyenne;
- médiane;
- mode;
- variance;
- écart-type;
- minimum;
- maximum;
- quartiles;
- nombre de valeurs manquantes.

#### Corrélations

L'application calcule la matrice de corrélation entre les colonnes numériques. Cette matrice est affichée sous forme de heatmap interactive pour identifier rapidement les relations positives ou négatives entre les variables.

#### Valeurs manquantes

L'application affiche un tableau contenant pour chaque colonne:

- le nombre de valeurs manquantes;
- le pourcentage de valeurs manquantes.

Un graphique permet aussi de visualiser les colonnes les plus touchées par les données manquantes.

#### Doublons

L'application calcule le nombre de lignes dupliquées et affiche les lignes concernées. Cette étape est importante car les doublons peuvent fausser les analyses statistiques.

### 6.4 Page Preprocessing

La page preprocessing est le cœur du nettoyage des données. Elle permet plusieurs opérations.

#### Gestion des valeurs manquantes

L'utilisateur peut choisir entre plusieurs stratégies:

- suppression des lignes contenant des valeurs manquantes;
- suppression des colonnes contenant des valeurs manquantes;
- remplacement par la moyenne pour les colonnes numériques;
- remplacement par la médiane;
- remplacement par le mode;
- remplacement par une valeur personnalisée.

#### Gestion des doublons

Un bouton permet de supprimer automatiquement les lignes dupliquées et de réinitialiser l'index du DataFrame.

#### Gestion des outliers

Les valeurs aberrantes sont détectées avec la méthode IQR. Pour une colonne numérique, on calcule:

- le premier quartile Q1;
- le troisième quartile Q3;
- l'écart interquartile IQR = Q3 - Q1;
- la borne inférieure Q1 - 1.5 × IQR;
- la borne supérieure Q3 + 1.5 × IQR.

Les valeurs en dehors de ces bornes sont considérées comme aberrantes et peuvent être supprimées.

#### Transformation des données

L'application propose:

- la normalisation Min-Max pour ramener les valeurs entre 0 et 1;
- la standardisation Z-score pour centrer et réduire les variables;
- l'encodage des variables catégorielles avec des colonnes binaires;
- le renommage des colonnes;
- le changement de type des colonnes;
- la sélection des variables utiles.

#### Historique des traitements

Chaque opération appliquée est ajoutée à un historique. Cela permet de suivre les étapes réalisées sur le dataset.

### 6.5 Page Visualisations

Cette page permet de générer différents graphiques interactifs:

- histogrammes pour étudier les distributions;
- boxplots pour détecter la dispersion et les outliers;
- scatter plots pour analyser la relation entre deux variables;
- bar charts pour les variables catégorielles;
- pie charts pour visualiser les proportions;
- heatmaps de corrélation;
- séries temporelles si une colonne date est disponible.

L'utilisateur peut choisir les colonnes à visualiser et personnaliser certains graphiques avec une variable de couleur.

### 6.6 Page Exportation

La page exportation permet de télécharger:

- le dataset nettoyé au format CSV;
- le dataset nettoyé au format Excel;
- un rapport d'analyse au format texte.

Le rapport généré contient les dimensions du dataset, le nombre de doublons, les valeurs manquantes et les statistiques descriptives.

### 6.7 Page À propos

Cette page présente brièvement le projet, son objectif et les technologies utilisées.

## 7. Dataset d'exemple

Le projet contient un fichier `data/sample_medical_data.csv`. Ce fichier représente un petit dataset médical avec les colonnes suivantes:

- `patient_id`: identifiant du patient;
- `age`: âge du patient;
- `gender`: sexe du patient;
- `bmi`: indice de masse corporelle;
- `glucose`: taux de glucose;
- `blood_pressure`: tension artérielle;
- `cholesterol`: cholestérol;
- `diagnosis`: diagnostic;
- `visit_date`: date de visite.

Ce dataset contient volontairement quelques valeurs manquantes et un doublon afin de tester les fonctionnalités de nettoyage.

## 8. Tests réalisés

Des tests unitaires ont été ajoutés pour vérifier les modules principaux. Les tests couvrent:

- la détection des dimensions, colonnes numériques et colonnes catégorielles;
- la détection des doublons;
- le calcul des valeurs manquantes;
- le calcul des statistiques descriptives;
- le calcul de la matrice de corrélation;
- le traitement des valeurs manquantes;
- l'encodage catégoriel;
- la suppression des doublons;
- la normalisation;
- la standardisation;
- la suppression des outliers;
- l'export CSV, Excel et rapport.

Commande de validation:

```bash
pytest -q
```

Résultat obtenu dans l'environnement de travail:

```text
4 passed, 1 skipped
```

Le test d'export Excel est ignoré localement si `openpyxl` n'est pas installé. Après installation avec `pip install -r requirements.txt`, l'export Excel sera disponible.

## 9. Mode d'installation et lancement

### 9.1 Installation des dépendances

```bash
pip install -r requirements.txt
```

### 9.2 Lancement de l'application

```bash
streamlit run app.py
```

Après le lancement, Streamlit affiche une URL locale, généralement:

```text
http://localhost:8501
```

## 10. Scénario de démonstration vidéo

Pour réaliser une vidéo de démonstration d'environ 5 minutes, on peut suivre le scénario suivant:

1. Présenter la page d'accueil et expliquer l'objectif de l'application.
2. Montrer les KPI cards: lignes, colonnes, doublons et mémoire.
3. Aller à la page `Importation des données` et importer un fichier CSV médical.
4. Afficher l'aperçu du dataset et les types des colonnes.
5. Aller à `Analyse exploratoire` et présenter les statistiques descriptives.
6. Afficher la heatmap de corrélation.
7. Montrer le tableau des valeurs manquantes et les doublons.
8. Aller à `Preprocessing` et appliquer un traitement des valeurs manquantes.
9. Supprimer les doublons puis appliquer une normalisation ou un encodage.
10. Aller à `Visualisations` et générer un histogramme, un boxplot et une heatmap.
11. Aller à `Exportation` et télécharger le dataset nettoyé ainsi que le rapport.
12. Conclure en expliquant l'intérêt de l'application pour les données médicales.

## 11. Points forts du projet

- Interface simple et organisée par sidebar.
- Séparation claire entre interface, statistiques, preprocessing, visualisation et exportation.
- Application utilisable avec n'importe quel fichier CSV tabulaire.
- Présence d'un dataset médical d'exemple.
- Fonctions de nettoyage adaptées aux problèmes fréquents des données médicales.
- Graphiques interactifs faciles à interpréter.
- Exportation des résultats pour réutilisation externe.
- Tests unitaires pour valider les fonctions critiques.

## 12. Limites et améliorations possibles

Même si l'application répond aux objectifs principaux, certaines améliorations peuvent être ajoutées:

- ajouter l'importation de fichiers Excel;
- exporter les graphiques directement en PNG;
- ajouter une authentification utilisateur;
- ajouter une sauvegarde automatique permanente des sessions;
- générer un rapport PDF automatique;
- ajouter une analyse spécifique pour les images biomédicales;
- intégrer des modèles de machine learning pour prédiction ou classification;
- ajouter des filtres dynamiques plus avancés.

## 13. Conclusion

Le projet **Prism Medical Data Lab** répond aux exigences d'une application de sciences de données médicales développée avec Python. Il permet d'importer, explorer, nettoyer, transformer, visualiser et exporter des données médicales tabulaires à travers une interface Streamlit claire et interactive.

Grâce à son architecture modulaire, le projet est facile à maintenir et à améliorer. Les tests ajoutés assurent la fiabilité des fonctions principales. L'application constitue donc une base solide pour l'analyse exploratoire et le preprocessing des données médicales dans un contexte académique ou professionnel.
## 14. Identité visuelle et design web

Pour rendre le projet plus professionnel et proche d'un vrai travail de recherche, une identité visuelle a été ajoutée à l'application. Elle comprend un logo principal, une icône de marque et un thème graphique cohérent.

Les éléments de design ajoutés sont:

- un logo SVG dans `assets/logo.svg`;
- une icône de marque dans `assets/brand_mark.svg`;
- un thème Streamlit dans `.streamlit/config.toml`;
- une sidebar sombre avec branding;
- une section d'accueil de type hero banner;
- des KPI cards modernes;
- des cartes de fonctionnalités;
- un workflow de recherche visuel;
- une interface organisée en tabs pour faciliter l'utilisation.

Cette amélioration permet de présenter l'application comme une plateforme de recherche sérieuse, claire et facile à utiliser par des étudiants, chercheurs ou analystes en santé digitale.