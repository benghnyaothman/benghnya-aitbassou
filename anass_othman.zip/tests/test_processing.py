import pandas as pd
import pytest

from utils.data_loader import dataset_overview
from utils.exporter import analysis_report_text, dataframe_to_csv_bytes, dataframe_to_excel_bytes
from utils.preprocessing import (
    encode_categorical,
    handle_missing_values,
    normalize_columns,
    remove_duplicates,
    remove_outliers_iqr,
    standardize_columns,
)
from utils.statistics import correlation_matrix, descriptive_statistics, missing_values_table


def sample_df():
    return pd.DataFrame({
        "age": [20, 30, 30, 1000],
        "glucose": [80.0, None, 120.0, 90.0],
        "gender": ["F", "M", "M", None],
    })


def test_dataset_overview_detects_columns_and_duplicates():
    df = pd.DataFrame({"a": [1, 1], "b": ["x", "x"]})
    overview = dataset_overview(df)
    assert overview["rows"] == 2
    assert overview["columns"] == 2
    assert overview["duplicates"] == 1
    assert overview["numeric_columns"] == ["a"]
    assert overview["categorical_columns"] == ["b"]


def test_missing_and_statistics_tables():
    df = sample_df()
    missing = missing_values_table(df)
    stats = descriptive_statistics(df)
    corr = correlation_matrix(df)
    assert missing.loc["glucose", "missing_count"] == 1
    assert "median" in stats.columns
    assert corr.shape == (2, 2)


def test_preprocessing_missing_duplicates_and_encoding():
    df = sample_df()
    filled = handle_missing_values(df, "mean")
    assert filled["glucose"].isna().sum() == 0
    encoded = encode_categorical(filled, ["gender"])
    assert "gender_F" in encoded.columns
    duplicated = pd.concat([df, df.iloc[[0]]], ignore_index=True)
    assert remove_duplicates(duplicated).shape[0] == df.shape[0]


def test_scaling_and_outlier_removal():
    df = pd.DataFrame({"age": [20, 21, 22, 23, 24, 1000], "glucose": [80, 82, 85, 87, 90, 95]})
    normalized = normalize_columns(df, ["glucose"])
    standardized = standardize_columns(df, ["glucose"])
    cleaned = remove_outliers_iqr(df, ["age"])
    assert normalized["glucose"].between(0, 1).all()
    assert round(float(standardized["glucose"].mean()), 7) == 0
    assert cleaned["age"].max() < 1000


def test_export_helpers_return_content():
    df = sample_df()
    assert dataframe_to_csv_bytes(df).startswith(b"age,glucose,gender")
    pytest.importorskip("openpyxl")
    assert len(dataframe_to_excel_bytes(df)) > 100
    assert "Nombre de lignes" in analysis_report_text(df)